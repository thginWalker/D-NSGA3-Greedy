The PFs of ZDT1-6 are downloaded from 
http://www.cs.cinvestav.mx/~emoobook/apendix-d/apendix-d.html