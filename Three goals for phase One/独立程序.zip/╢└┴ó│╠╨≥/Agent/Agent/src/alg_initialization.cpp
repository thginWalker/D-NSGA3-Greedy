#include "alg_initialization.h"
#include "problem_self.h"
#include "alg_individual.h"
#include "alg_population.h"
#include "aux_math.h"

#include <cstddef>
using std::size_t;

CRandomInitialization RandomInitialization;
/*
void CRandomInitialization::operator()(CIndividual *indv, const CProblemSelf &prob) const
{
	int t[1000];
	CIndividual::TDecVec &x = indv->vars();
	x.resize(prob.num_variables());
	int idx = prob.num_agent;
	for (size_t i=0; i<prob.num_agent; i+=1)
	{
		x[i] = MathAux::randomInt(prob.lower_bounds()[i], prob.upper_bounds()[i]);//MathAux::random(prob.lower_bounds()[i], prob.upper_bounds()[i]);
		MathAux::randPermutation(t,prob.agt[i].tskn);
		for (int j = idx; j < idx+x[i]; j++)
		{
			x[j] = prob.agt[i].tsks[t[j - idx]];
		}
		idx = idx + x[i];
	}
	CIndividual::removedup(indv, prob.num_agent);
}*/
/*
void CRandomInitialization::operator()(CIndividual *indv, const CProblemSelf &prob) const
{
	int t[1000];
	CIndividual::TDecVec &x = indv->vars();
	x.resize(prob.num_variables());
	for (int i = 0; i < x.size(); i++)
		x[i] = 0;
	CIndividual::TDecVec y;
	y.resize(prob.num_task);
	CIndividual::TDecVec z;
	z.resize(prob.num_agent,0);
	MathAux::randPermutation(t, prob.num_task);
	for (size_t i = 0; i<prob.num_task; i += 1)
	{
		int w = rand() % prob.tsk[t[i]].agtn;
		y[i] = prob.tsk[t[i]].agts[w];
		x[y[i]]++;
	}
	z[0] = 0;
	for (int i = 1; i < prob.num_agent; i++)
	{
		z[i] = z[i - 1] + x[i - 1];
	}
	for (int i = 0; i < prob.num_task; i += 1)
	{
		x[z[y[i]] + prob.num_agent] = t[i];
		z[y[i]] = z[y[i]] + 1;
	}
}*/
void CRandomInitialization::operator()(CIndividual *indv, const CProblemSelf &prob) const
{
	int t[1000];
	CIndividual::TDecVec &x = indv->vars();
	x.resize(prob.num_variables());
	for (int i = 0; i < x.size(); i++)
		x[i] = 0;
	int n = 0;;
	for (int i = 0; i < prob.num_agent; i++)
	{
		MathAux::randPermutation(t, prob.agt[i].tskn);
		for (int j = n; j < n + prob.agt[i].tskn; j++)
			x[j] = prob.agt[i].tsks[t[j - n]];
		n = n + prob.agt[i].tskn;
	}
}
// ----------------------------------------------------------------------
void CRandomInitialization::operator()(CPopulation *pop, const CProblemSelf &prob) const
{
	for (size_t i=0; i<pop->size(); i+=1)
	{
		(*this)( &(*pop)[i], prob );
	}
}