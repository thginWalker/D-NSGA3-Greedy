#define _CRT_SECURE_NO_WARNINGS
#include "problem_base.h"
#include "problem_self.h"
#include "alg_nsgaiii.h"
#include "alg_population.h"
#include "exp_experiment.h"

#include <ctime>
#include <cstdlib>
#include <iostream>
#include <fstream>
#include <string>

#include "stdio.h"
#include "io.h"
#include "gnuplot_interface.h"
#include "log.h"
#include "aux_misc.h"
#include "exp_indicator.h"

using namespace std;
#define agtID 1
int main()
{
	ifstream exp_list("explist.ini");
	char filename[50],filename1[50];
	sprintf(filename, "D:\\DataEx\\ind_%d.txt", agtID);
	sprintf(filename1, "D:\\DataEx\\eval_%d.txt", agtID);
	FILE * fp,*fp1;
	if (!exp_list) { cout << "We need the explist.ini file." << endl; return 1; }

	string exp_name;
	while (exp_list >> exp_name)
	{
		ifstream exp_ini("Experiments\\" + exp_name);
		if (!exp_ini) { cout << exp_name << " file does not exist." << endl; continue; }

		// ----- Setup the expriment ------
		CNSGAIII nsgaiii;
		CProblemSelf *problem;
		//problem = &prob;
		SetupExperiment(nsgaiii, &problem, exp_ini);
		CIndividual ind;
		while (true)
		{
			if(_access(filename, 0) == -1)
				continue;
			ind.vars().resize(problem->num_variables());
			ind.objs().resize(problem->num_objectives());
			fp = fopen(filename, "r");
			int n = 0;
			for (int i = 0; i < problem->num_agent; i++)
			{
				for (int j = 0; j < problem->agt[i].tskn; j++)
				{
					fscanf(fp, "%d", &ind.vars()[n++]);
				}
			}
			problem->Evaluate(&ind);
			fclose(fp);
			remove(filename);

			fp1 = fopen(filename1, "w");
			fprintf(fp1, "%lf %lf %lf %lf", ind.objs()[0], ind.objs()[1], ind.objs()[2], ind.objs()[3]);
			fclose(fp1);
		}
	}// while - there are more experiments to carry out
	system("pause");
	return 0;
}
